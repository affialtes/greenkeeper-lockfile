<?php
/**
 Plugin Name: Byepass
 Plugin URI: https://byepass.co/
 Description: A plugin to enables passwordless login to Wordpress using Byepass.
 Author URI: https://byepass.co/
 Domain Path: /languages
 Text Domain: byepass
 Version: 1.0.0
 */

// don't load the plugin file directly
if ( ! defined( 'ABSPATH' ) ) exit;

class byepass_plugin {

	public function __construct() {

		add_action( 'admin_init', array( $this, 'register_mysettings' ) );
		add_action( 'admin_menu', array( $this, 'byepass_info_menu' ) );

		// Handle localisation
		add_action( 'plugins_loaded', array( $this, 'i18n' ), 0 );
    
		//only show our login form if we have a key alredy	
		if (get_option('byepass_key') and strlen(get_option('byepass_key')) >= 32 and $GLOBALS['pagenow'] === 'wp-login.php') {	
			add_action('init', array($this, 'byepass_login'));	
		} else if (get_option('byepass_key') and strlen(get_option('byepass_key')) >= 32) {
			
		} else {
			add_action( 'admin_notices', array( $this, 'byepass_register_notice' ) );
		}	

	}
	
	public function byepass_register_notice() {
	    ?>
	    <div class="notice notice-success is-dismissible">
	        <p><a href="<?php echo admin_url('options-general.php?page=byepass'); ?>"><?php _e( 'Get API Keys for Byepass here to enable passwordless login!', 'byepass' ); ?></a></p>
	    </div>
	    <?php
	}

	public function register_mysettings() {
		register_setting( 'byepass-settings', 'byepass_email' );
		register_setting( 'byepass-settings', 'byepass_key' );
		register_setting( 'byepass-settings', 'byepass_secret' );
	}


    // Register submenu
    public function byepass_info_menu() {
        add_submenu_page(
            'options-general.php',
            __( 'Byepass Login', 'byepass' ),
            __( 'Byepass Login', 'byepass' ),
            'manage_options',
            'byepass',
            array( $this, 'byepass_info_page' )
        );
    }



	public function byepass_get_url($the_url, $max_try) {
		$cur_loop = 0;
		while (FALSE == $url = file_get_contents($the_url)) {
			$cur_loop++;
			if ($cur_loop >= $max_try) {
				break;
			}
		}

		return $url;
	}



	public function update_byepass_info($email,$callback) {

		$email = sanitize_email($email);
		$callback = esc_url_raw($callback);

		if (!is_email($email)) { echo "bad email"; die; }
		if (!wp_http_validate_url($callback)) { echo "bad url"; die; }

		$ur =
			"https://byepass.co/api/enroll/".
			"?platform=wordpress&version=".get_bloginfo( 'version' ).
			"&redirect=".addslashes($callback).
			"&identifier=".$email;

		$data = $this->byepass_get_url($ur, 5);

		if ($data) {
			$json = json_decode($data);
			if ($json->status == "200") {
				update_option( 'byepass_email', $email );
				update_option( 'byepass_key', $json->key );
				update_option( 'byepass_secret', $json->secret );
				
				remove_action( 'admin_notices', array( $this, 'byepass_register_notice' ) );

				//add_action('login_head', array($this, 'byepass_login'));

			}
		}

	}



	public function byepass_info_page() {
		$current_user = wp_get_current_user();
		if (isset($_POST['byepass_email']) and isset($_POST['byepass_callback'])) {
			$this->update_byepass_info($_POST['byepass_email'],$_POST['byepass_callback']);
		} else if (isset($_POST['byepass_reset']) and $_POST['byepass_reset'] == 1) {
			update_option( 'byepass_email', NULL );
			update_option( 'byepass_key', NULL );
			update_option( 'byepass_secret', NULL );
			
			add_action( 'admin_notices', array( $this, 'byepass_register_notice' ) );
		}
	?>

	<h1><?php _e( 'Byepass - Passwordless Logins', 'byepass' ); ?></h1>

	<form method="post" action="#">

		<table class="form-table">
		<?php if (strpos(get_option('byepass_email'),"@") and strlen(get_option('byepass_key')) >= 32 and strlen(get_option('byepass_secret')) >= 32) { ?>		      

			<tr valign="top"><td><?php _e( 'Byepass is configured!', 'byepass' ); ?></td></tr>

			<tr valign="top"><td>
				<?php
				/* translators: prints email address, keep space after colon */
				printf(
					__( 'To login use your Wordpress email: ', 'byepass' ),
						sanitize_email( get_option( 'byepass_email' ) )
					);
				?>
			</td></tr>

			<tr valign="top"><td>
				<a href="https://byepass.co" target="_blank"><?php _e( 'Login to Byepass.co to check stats', 'byepass' ); ?></a>
			</td></tr>

			<tr valign="top">
				<th scope="row"><?php _e( 'Your email (registered with Byepass):', 'byepass' ); ?></th>
				<td><input type="text" name="" value="<?php echo sanitize_email(get_option('byepass_email')); ?>" disabled="disabled"/></td>
			</tr>

			<tr valign="top">
				<th scope="row"><?php _e( 'Key:', 'byepass' ); ?></th>
				<td><input type="text" name="" value="<?php echo sanitize_text_field(get_option('byepass_key')); ?>" disabled="disabled"/></td>
			</tr>

			<tr valign="top">
				<th scope="row"><?php _e( 'Secret:', 'byepass' ); ?></th>
				<td><input type="text" name="" value="<?php echo sanitize_text_field(get_option('byepass_secret')); ?>" disabled="disabled"/></td>
			</tr>
			<input type="hidden" name="byepass_reset" value="1">
			<?php submit_button( __( 'Reset/Clear Settings', 'byepass' ) ); ?>

		<?php } else { ?>

			<tr valign="top"><th><?php _e( 'Let\'s get your API keys!', 'byepass' ); ?></th></tr>

			<tr valign="top">
				<th scope="row"><?php _e( 'Your email (registered with Byepass):', 'byepass' ); ?></th>
				<td><input type="text" name="byepass_email" value="<?php echo $current_user->user_email; ?>"/></td>
			</tr>

			<tr valign="top">
				<th scope="row"><?php _e( 'Redirect URL (Don\'t change unless you know what you are doing.', 'byepass' ); ?></th>
				<td><input type="text" name="byepass_callback" value="<?php echo site_url()."/wp-login.php"; ?>"/></td>
			</tr>
			<input type="hidden" name="byepass_reset" value="0">
			<?php submit_button( __( 'Get API Keys', 'byepass' ) ); ?>

		<?php } ?>

		</table>

		

	</form>

	<?php
	}

	public function byepass_login() {


		$url = site_url() . '/wp-admin';

		if (isset($_REQUEST['challengeId'])) {

			$challengeId = isset($_REQUEST['challengeId']) ? $_REQUEST['challengeId'] : false;
			$oth = isset($_REQUEST['oth']) ? $_REQUEST['oth'] : false;
			$identifier = isset($_REQUEST['identifier']) ? $_REQUEST['identifier'] : false;

			if ($identifier and $challengeId and $oth) {

				$challengeId = sanitize_text_field($challengeId);
				$oth = sanitize_text_field($oth);
				$identifier = sanitize_email($identifier);

				$user = get_user_by('email', $identifier);

				//ensure user exists as a wordpress user before attempting to login with Byepass
				if (empty($user->ID)) {
					echo '<div id="login_error"><strong>' . __( 'Error:' , 'byepass' ) . '</strong>: ' . __( 'Invalid email address, please use your Wordpress user email address.', 'byepass' ) .'</div>';

				//user exists let's authenticate with Byepass
				} else {

					$ur =
						"https://byepass.co/api/verify/".
						"?challengeId=$challengeId".
						"&oth=$oth".
						"&identifier=$identifier".
						"&key=" . sanitize_text_field(get_option('byepass_key')).
						"&secret=" .sanitize_text_field(get_option("byepass_secret"));

					$data = $this->byepass_get_url($ur, 5);

					if ($data === false) {
						// error message
						echo '<div id="login_error"><strong>' . __( 'Error communicating with Byepass', 'byepass' ) . '</strong>.</div>';
						exit;
					} else {
						$json = json_decode($data);
						if ($json->success and (time() - strtotime($json->challenge_ts) < 300)) {
							$user = get_user_by('email', $identifier);
							if (!empty($user->ID)) {
								wp_set_auth_cookie($user->ID, 0);
								if (wp_redirect(admin_url())) {
									exit;
								}
							} else {
								echo '<div id="login_error"><strong>' . __( 'Error:' , 'byepass' ) . '</strong>: ' . __( 'Invalid email address, please use your Wordpress user email address.', 'byepass' ) . '</div>';
							}
						} else if ($json->success and (time() - strtotime($json->challenge_ts) > 300)) {
							echo '<div id="login_error"><strong>' . __( 'Error: authorisation expired, login again', 'byepass' ) . '</strong></div>';
						} else {
							/* translators: prints status message */
							printf(
								'<div id="login_error"><strong>' . __( 'Error: (%s)', 'byepass' ) . '</strong></div>',
									esc_html( $json->status )
							);
						}


					}
				}
			}
		}


		wp_enqueue_style( 'byepass-custom-css', plugins_url() . '/byepass/style.css', __FILE__ ) ;
		
		echo
			'<form method="post" id="bsubmit" style="background:transparent;box-shadow:none;" action="https://byepass.co/redirect" method="post">'.
				'<input type="hidden" name="key" value="' . get_option("byepass_key") . '">'.
				'<input type="hidden" name="identifier" placeholder="' . __( 'Email', 'byepass' ) . '" required="">'.
			'</form>';
		
		wp_register_script( 'byepass-i18n', plugins_url() . '/byepass/custom.js', array('jquery'), null, true );
		wp_localize_script( 'byepass-i18n', 'objectL10n', array(
			'submit' => __( 'Byepass Login', 'byepass' ),
			'email'  => __( 'Email Address', 'byepass' ) . '<br><input type="text" name="log" id="user_login" class="input" value="" size="20">'
		) );
		
		wp_enqueue_script('byepass-i18n');
	}

	// Loads the translation file.
	function i18n() {

		load_plugin_textdomain( 'byepass', false, basename( dirname( __FILE__ ) ) . '/languages/' );

	}

}

new byepass_plugin();

?>
